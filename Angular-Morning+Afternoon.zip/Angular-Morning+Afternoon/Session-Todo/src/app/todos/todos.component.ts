import { Component, OnInit } from '@angular/core';
import {ApiService} from '../service/api.service';

@Component({
  selector: 'app-todos',
  templateUrl: './todos.component.html',
  styleUrls: ['./todos.component.scss']
})
export class TodosComponent implements OnInit {
  todos:any;
  singleTodo: any;
  constructor(private api : ApiService) { }
  id:any;
  getDetails(id:number){
    this.api.getDataById(id).subscribe((item)=>{
      this.singleTodo = item;
      console.log(this.singleTodo);
    })
  }

  selectedTodo : any;
  onSelecttodo(todo: any){
    this.selectedTodo = todo;
  };
  
  ngOnInit(): void {
    this.api.getData().subscribe((item)=>{
      this.todos=item;
      // console.log(this.todos);
    })
  }

}
