import { Component, OnInit } from '@angular/core';
import {SessionModel} from '../sessionModel';
import {SessionService} from '../service/session.service';

@Component({
  selector: 'app-sessions',
  templateUrl: './sessions.component.html',
  styleUrls: ['./sessions.component.scss']
})
export class SessionsComponent implements OnInit {
  sessions: SessionModel[]=[];
  constructor(private Service : SessionService) {
   }
   selectedSession : SessionModel = new SessionModel();
   onSelect(session: SessionModel){
     this.selectedSession = session;
   };

   delete_session(session: SessionModel){
      
    let index = this.sessions.indexOf(session);
    this.sessions.splice(index, 1);
  }

  add_item(f: any): void{
    if(f.name != ""){
    this.sessions.push({name:f.name,trainer:f.trainer,joined:f.joined}); 
    }
  }

  ngOnInit(): void {
    this.sessions = this.Service.previous;
    console.log(this.sessions);
  }

}


