export class TodoModel {
    userId:number = 0;
    Id:number = 0;
    Title:string="";
    Completed:boolean = true;
}