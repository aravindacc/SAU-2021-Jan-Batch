export class SessionModel {
    name: string ="" ;
    trainer: string ="";
    joined?: any;
  }