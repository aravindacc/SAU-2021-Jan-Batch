import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SessionsComponent } from './sessions/sessions.component';
import { TodosComponent } from './todos/todos.component';

const routes: Routes = [
  {
    path:'',
    component:SessionsComponent
  },
  {
    path:'todo',
    component:TodosComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }






// const routes: Routes = [
//   {
//     path:'session',
//     component:SessionComponent
//   },
//   {
//     path: 'todo',
//     component:TodoComponent
//   }
// ];