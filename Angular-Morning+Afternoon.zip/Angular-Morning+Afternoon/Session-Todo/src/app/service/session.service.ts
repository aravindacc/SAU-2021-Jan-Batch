import { Injectable } from '@angular/core';
import {SessionModel} from '../sessionModel';

@Injectable({
  providedIn: 'root'
})
export class SessionService {

  constructor() { }
  previous:SessionModel[] =[
    {
       name:"VCS",
       trainer:"Devansh sharma",
       joined: new Date,
       
    },
    {
       name:"RDBMS concepts ",
       trainer:"Sivagami S",
       joined: new Date,
       
    },
    {
      name:"SQL concepts ",
      trainer:"Sivagami S",
      joined: new Date,
      
   },
   {
    name:"No SQL",
    trainer:"Abhisek Nandan",
    joined: new Date,
    
 },
 {
  name:"HTML/CSS",
  trainer:"Vignesh",
  joined: new Date,
  
},
  ];
}
