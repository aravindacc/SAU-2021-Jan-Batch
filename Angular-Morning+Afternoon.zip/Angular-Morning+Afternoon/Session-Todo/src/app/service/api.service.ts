import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  constructor( private http : HttpClient) {}

  getData() {
    const url = 'https://jsonplaceholder.typicode.com/todos?_limit=20';
    return this.http.get(url);
  }
  getDataById(id:number){
    const url1 = 'https://jsonplaceholder.typicode.com/todos/' + id;
    return this.http.get(url1);
  }
}

