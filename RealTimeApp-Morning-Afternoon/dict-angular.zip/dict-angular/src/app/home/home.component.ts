import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Word } from '../Models/Words';
import { WordService } from '../word.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  searchWord:any;
  historyWords:Array<Word> = [];
  words: Array<Word> = [];
  editableWord: Word = null;

  form = new FormGroup({
    sortBy: new FormControl('', Validators.required)
  });


  patternForm = new FormGroup({
    pattern: new FormControl('', Validators.required)
  })
  constructor(private wordService: WordService) { }

  optionsList: any = [
    "Id",
    "Word",
    "Meaning",
    "Part Of Speech",
    "Example",
  ];

  ngOnInit(): void {
    // this.wordService.getSuccess().subscribe(resp=>{
    //   console.log(resp);
    // })
    this.searchWord=document.getElementById('search');
    this.wordService.getAll().subscribe(words => {
      this.words = words;
      this.historyWords=words;
      console.log(words);
    });
  }

  edit(word: Word): void {
    this.editableWord = word;
  }

  delete(word: Word): void {
    this.wordService.deleteWord(word.id).subscribe(res => {
      console.log(res);
      if(res) {
        this.words = this.words.filter(oldWord => word.id != oldWord.id);
      }
    })
  }

  updateWord($event: Word): void {
    console.log($event);
    const obj: Word = {
      word: $event.word,
      partOfSpeech: $event.partOfSpeech,
      example: $event.example,
      meaning: $event.meaning,
      id: $event.id,
      creationTm: null,
      lastModifiedTm: null
  };
  this.wordService.updateWord(obj).subscribe(res=>{
    console.log(res);
  })
}
patternMatch() {
  console.log(this.patternForm.value.pattern);
  this.searchWord.value='';
  this.wordService.matchPattern(this.patternForm.value.pattern).subscribe(resp => {
    console.log(resp);
    if (resp) {
      this.words = resp;
    }
  })
}
reset(){
  this.words=this.historyWords;
  console.log(this.words);
}

sort() {
  console.log(this.form.value);

  switch (this.form.value.sortBy) {
    case "Id":
      this.sortObj(this.words,"id");
      break;
    case "Word":
      this.sortObj(this.words,"word");
      break;
    case "Meaning":
      this.sortObj(this.words,"meaning");
      break;
    case "Part Of Speech":
      this.sortObj(this.words,"partOfSpeech");
      break;
    case "Example":
      this.sortObj(this.words,"example");
      break;
  }
}

sortObj(list, key) {
  function compare(a, b) {
      a = a[key];
      b = b[key];
      var type = (typeof(a) === 'string' ||
                  typeof(b) === 'string') ? 'string' : 'number';
      var result;
      if (type === 'string') result = a.localeCompare(b);
      else result = a - b;
      return result;
  }
  return list.sort(compare);
}

}

