package com.realTimeApp.Dictionary;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DictionaryApplicationTests {

	@Test
	void contextLoads() {
	}

}
